CREATE TABLE Felhasznalo (
    felhasznalonev VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    jelszo VARCHAR(100) NOT NULL,
    keresztnev VARCHAR(50),
    vezeteknev VARCHAR(50),
    szuletesiDatum INT,
    cim VARCHAR(255),
);

CREATE TABLE Admin (
    felhasznalonev VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    jelszo VARCHAR(100) NOT NULL,
    keresztnev VARCHAR(50),
    vezeteknev VARCHAR(50),
    szuletesiDatum INT,
    cim VARCHAR(255),
    admin_since INT
);



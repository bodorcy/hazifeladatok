### Összefoglaló az `1.` mérföldkőben végzett munkáról

### Projekt tag: `Vincze Nándor`

___

#### Vállalásaim a mérföldkőben: 

 - 8.1.1. Projektterv rám eső részének kitöltése

    ##### A feladat elvégzését alátámasztó commit:

     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/commit/6cf8548d8ab4a0cf73434685e9f6091d2754ca8d
___

 - Backend sablon létrehozása

     ##### A feladathoz tartozó issue:
     
     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/issues/5#note_184626

     ##### A feladat elvégzését alátámasztó commitok:
     
     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/commit/08fe29407d4f110d9ee8f352e1ab3045413d4550
     
     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/commit/0376814edd17a7e46c98de1ed666b06a849449ff       
___
 - Egyéni jelentés mappa létroházsa és elkészítése
 
     ##### A feladathoz tartozó issue:
     
     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/issues/9
     
     #### A feladat elvégzését alátámasztó commitok:
     
     - https://git-okt.sed.inf.szte.hu/2024_IB153I-6_E/repulo/-/commit/6d4b033993794c459755cf6d7d84de5b109b1ae5

#### Megjegyzések

Ha van ..


```
Csak az adott mérföldkő feladatait igazoló commit-okat másolj ide!
Egy korábbi feladat teljesítését igazoló commit (csak azért mert ennek a mérföldkőnek az időszakába esik)
 nem fogadható el a mérföldkőben végzett munkának.
```
